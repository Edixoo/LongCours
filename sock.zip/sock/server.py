import socket
import threading
from world import world

monde = world()

IP = "127.0.0.1"  
PORT = 5555  

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((IP, PORT))

clients = {}

# fonction pour gérer la connexion d'un client
def handle_client(conn, addr):
    print(f"Nouvelle connexion établie : {addr}")

    # réception du nom du client
    conn.send("NOM".encode())
    name = conn.recv(1024).decode()
    
    conn.send("COLOR".encode())
    colors = conn.recv(1024).decode()
    clients[conn] = name
    clients[colors] = colors
    print("hello" + name + "\n"+ colors)

    broadcast(f"{name} vient de rejoindre la partie".encode())

    # création des joueurs et envoi des données aux clients
    # monde.definirjoueurs()
    joueurs = []
    for joueur in monde.listejoueur:
        joueur_dict = {
            'id': joueur.id,
            'pseudo': joueur.pseudo,
            'couleur': joueur.couleur
        }
        joueurs.append(joueur_dict)
    
    joueurs_str = str(joueurs)
    print(f"Envoi des données des joueurs : {joueurs_str}")
    conn.send(joueurs_str.encode())
    
    nb_joueurs = len(joueurs)
    nb_joueurs_str = str(nb_joueurs)
    conn.send(nb_joueurs_str.encode())

    while True:
        try:
            message = conn.recv(1024)
            broadcast(message, name + ": ")
        except:
            conn.close()
            del clients[conn]
            broadcast(f"{name} vient de quitter le jeu.".encode())
            break

# def distribuercarte():
    

# fonction pour diffuser un message à tous les clients
def broadcast(message, prefix=""):
    for client in clients:
        client.send(prefix.encode() + message)

def start():
    server.listen()
    print(f"Serveur en écoute sur {IP}:{PORT}...")

    # les connexions clients
    while True:
        conn, addr = server.accept()
        thread = threading.Thread(target=handle_client, args=(conn, addr))
        thread.start()
        print(f"Nombre de connexions actives : {threading.activeCount() - 1}")

print("Démarrage du jeu...")
start()

